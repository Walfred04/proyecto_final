<?php
	session_start();
	include('php/util.php');
	cabecera('Examen final');
?>

<body>
	<main>
		<?php
			impHeader();
			impNavbar();
			impImgPrincipal("./imgs/hotel3.png");
		?>

		<div id="cuerpo">
			<?php
				impHoteles();
				impFinanciacion();
				impVendidos();
			?>
		</div>

		<?php
			footer();
		?>
	</main>

	<!--MODAL Carrito-->
	<?php
		modalCarrito(1);
	?>

	<!--MODAL grafica-->
	<?php
		modalGrafica();
	?>


	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

	<?php
		echo "<script type='text/javascript'>
      			google.charts.load('current', {'packages':['corechart']});
      			google.charts.setOnLoadCallback(drawChart);

      	function drawChart() {

        var data = google.visualization.arrayToDataTable([
        	['Task', 'Hours per Day']\n";
		$sql = conectar();

		$query = "select nombre, n_vuelos_vendidos FROM destinos";
		$result = mysqli_query($sql, $query);

		while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
			echo ",['".$row[0]."', ".$row[1]."]\n";
		}

	echo "]);

	        var options = {
	          title: 'My Daily Activities'
	        };

	        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

	        chart.draw(data, options);
	      }
	    </script>";

	?>
	
</body>
</html>