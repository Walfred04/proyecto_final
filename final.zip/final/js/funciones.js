//Funcion para desplegar mas info
function masInfo(id, tipo){
	window.location.href = "info.php?id=" + id + "&tipo=" + tipo;
}

//Funciones para el carrito
function borrarTabla(){
	var tabla = document.getElementById('tablaCarrito');
	console.log(tabla.rows.length);
	var numRows = tabla.rows.length;

	for(var i=1; i<numRows; i++){
		tabla.deleteRow(1);
	}

	totalCompra = 0;
	document.getElementById('totalCompra').innerHTML  = totalCompra.toString();
	carro = [];
}


function agregar(id, descripcion, precio){
	var tabla = document.getElementById('tablaCarrito');
	var numRows = tabla.rows.length;

	var fila = tabla.insertRow(tabla.rows.length);
	var c0 = fila.insertCell(0);
	var c1 = fila.insertCell(1);
	var c2 = fila.insertCell(2);
	var c3 = fila.insertCell(3);
			
	////////////////////////////////////////////////////		
	c0.innerHTML = "<input type='hidden' value='"+id+"' name='id["+numRows+"]'>";
	////////////////////////////////////////////////////		
	c1.innerHTML = "<p id='d"+numRows+"'>" +descripcion + "</p> ";		
	////////////////////////////////////////////////////		
	c2.innerHTML = "<p>" +precio + "</p> ";			
	////////////////////////////////////////////////////		
	c3.innerHTML = "<p>" +(precio) + "</p> ";			

	totalCompra += parseInt(precio);
	document.getElementById('totalCompra').innerHTML  = totalCompra.toString();
}

var totalCompra = 0;