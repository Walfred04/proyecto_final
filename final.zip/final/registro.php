<?php
include("php/util.php");
cabecera("Registro");
function validarPasswords($password, $password2){
	if($password != $password2)
		return false;
	else
		return true;
}

function validarEmailExistente($email){
	$sql = conectar();
	$query = "SELECT email from usuarios where email='$email'";
	$result = mysqli_query($sql, $query);
	mysqli_close($sql);
	if(mysqli_num_rows($result)>0)
		return false;
	else
		return true;
}

$validacionPassword = "";
$validacionEmail = "";

if(isset($_POST['usuario']) && isset($_POST['email']) && isset($_POST['password']) && isset($_POST['password2'])){
	$usuario = $_POST['usuario'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$password2 = $_POST['password2'];

	
	if(!validarPasswords($password, $password2))
		$validacionPassword = "error";
	if(!validarEmailExistente($email))
		$validacionEmail = "error";

	if($validacionEmail!="error" && $validacionPassword!="error"){
		$sql = conectar();
		$insert = "INSERT INTO usuarios(id, username, password, email, tipo) VALUES (NULL, '$usuario', '$password', '$email', '0')";
		mysqli_query($sql, $insert);
		
		$query = "SELECT id, username, password, email, tipo from usuarios where email='$email' and password='$password'";
		$result = mysqli_query($sql, $query);
		mysqli_close($sql);
		if($row = mysqli_fetch_array($result, MYSQLI_NUM)){
			session_start();
			$_SESSION['id'] = $row[0];
			$_SESSION['nombre'] = $row[1];
			$_SESSION['usuario'] = $row[3];
	    $_SESSION['tipo'] = $row[4];
	   }
		header('Location: index.php');
	}
}
?>

<body>
   <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-2 col-xl-4"></div>
            <div class="col-lg-4 col-md-4 col-sm-8 col-xl-4">
                <form action="registro.php" method="post">
                    <div class="form-login login">
                        <h5>Bienvenido, ingresa tus datos</h5>
                        <label for="usuario">Nombre de usuario</label>
                        <input name="usuario" type="text" id="usuario" class="form-control my-2"/><br/>
                        <label for="email">E-mail
                        	<?php
                        		if($validacionEmail == "error")
                        			echo "<p style=color:red> El email ".$email." ya esta registrado</p>";
                        	?>
                        </label>
                        <input name="email" type="text" id="email" class="form-control my-2"/><br/>
                        <label for="password">Password</label>
                        <input name="password" type="text" id="password" class="form-control my-2"/><br/>
                        <label for="password2">Repetir password
                        	<?php
                        		if($validacionPassword == "error")
                        			echo "<p style=color:red> Los password no coinciden</p>";
                        	?>
                        </label>
                        <input name="password2" type="text" id="password2" class="form-control my-2"/><br/>
                        <div class="wrapper">
                            <span class="group-btn">     
                                <button type="submit" class="btn btn-primary btn-md">Continuar <i class="fa fa-sign-in"></i></button>
                            </span>
                        </div>
                    </div>
                </form>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-2 col-xl-4"></div>
        </div>
    </div>
</body>
</html>