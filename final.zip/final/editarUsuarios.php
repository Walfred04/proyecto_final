<?php
	session_start();
	include('php/util.php');
	cabecera('Examen final');
?>

<body>
	<main>
		<?php
			impHeader();
			impNavbar();
		?>

		<div id="cuerpo">
			<section class="container">
				<table class="table table-hover">
				  <thead>
				    <tr>
				      <th>id</th>
				      <th>E-mail</th>
				      <th>Tipo</th>
				      <th> </th>
				      <th> </th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php
				  		$sql = conectar();
				  		$query = "select id, email, tipo from usuarios";
				  		$result = mysqli_query($sql, $query);
				  		mysqli_close($sql);
				  		while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
				  			echo "<tr>
									      <th scope='row'>".$row[0]."</th>
									      <td>".$row[1]."</td>
									      <td>".$row[2]."</td>
									      <td><a onclick='eliminarUsuario(".$row[0].")'> Eliminar</a></td>
									      <td><a onclick='volverAdmin(".$row[0].")'> Volver admin</a></td>
									    </tr>";
				  		}
				  	?>
				  </tbody>
				</table>
				<br/>
			</section>
		</div>

		<?php
			footer();
		?>
	</main>

	<!--MODAL Carrito-->
	<?php
		modalCarrito(0);
	?>

	<!--MODAL grafica-->
	<?php
		modalGrafica();
	?>

	<script type='text/javascript'>
		function eliminarUsuario(id){
			var agree=confirm("¿Realmente desea eliminarlo? ");
  		if(agree)
     		window.location.href = "delete.php?id="+ id; 
			else
    		alert('No se elimino el registro');
		}

		function volverAdmin(id){
			var agree=confirm("¿Realmente desea volverlo administrador? ");
  		if(agree)
     		window.location.href = "volverAdmin.php?id="+ id; 
			else
    		alert('No se volvio administrador');

		}
		
	</script>

	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

	<?php
		echo "<script type='text/javascript'>
      			google.charts.load('current', {'packages':['corechart']});
      			google.charts.setOnLoadCallback(drawChart);

      	function drawChart() {

        var data = google.visualization.arrayToDataTable([
        	['Task', 'Hours per Day']\n";
		$sql = conectar();

		$query = "select nombre, n_vuelos_vendidos FROM destinos";
		$result = mysqli_query($sql, $query);

		while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
			echo ",['".$row[0]."', ".$row[1]."]\n";
		}

	echo "]);

	        var options = {
	          title: 'My Daily Activities'
	        };

	        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

	        chart.draw(data, options);
	      }
	    </script>";

	?>
	
</body>
</html>