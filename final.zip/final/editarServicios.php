<?php
	session_start();
	include('php/util.php');
	cabecera('Examen final');
?>

<body>
	<main>
		<?php
			impHeader();
			impNavbar();
		?>

		<div id="cuerpo">
			<section class="container">
				<h2 class="d-inline-block">Vuelos</h2>
				<table class="table table-hover">
				  <thead>
				    <tr>
				      <th>id</th>
				      <th>Nombre</th>
				      <th>Costo</th>
				      <th>Imagen</th>
				      <th>Total</th>
				      <th>Vendidos</th>
				      <th> </th>
				      <th> </th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php
				  		$sql = conectar();
				  		$query = "select id, nombre, costo, url_img, n_vuelos_total, n_vuelos_vendidos from destinos";
				  		$result = mysqli_query($sql, $query);
				  		while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
				  			echo "<tr>
									      <th scope='row'>".$row[0]."</th>
									      <td>".$row[1]."</td>
									      <td>".$row[2]."</td>
									      <td>".$row[3]."</td>
									      <td>".$row[4]."</td>
									      <td>".$row[5]."</td>
									      <td><a onclick='editar(".$row[0].", 0)'>Editar</a></td>
									      <td><a onclick='eliminar(".$row[0].", 0)'>Eliminar</a></td>
									    </tr>";
				  		}
				  	?>
				  </tbody>
				</table>
				<button type="button" class="btn btn-primary" onclick="agregar('0')">Agregar vuelo</button>
				<br/><br/><br/>

				<h2 class="d-inline-block">Hoteles</h2>
				<table class="table table-hover">
				  <thead>
				    <tr>
				      <th>id</th>
				      <th>Nombre</th>
				      <th>Costo</th>
				      <th>Imagen</th>
				      <th>Total</th>
				      <th>Vendidos</th>
				      <th> </th>
				      <th> </th>
				    </tr>
				  </thead>
				  <tbody>
				  	<?php
				  		$sql = conectar();
				  		$query = "select id, nombre, costo, url_img, n_habitaciones_total, n_habitaciones_vendidos from hoteles";
				  		$result = mysqli_query($sql, $query);
				  		while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
				  			echo "<tr>
									      <th scope='row'>".$row[0]."</th>
									      <td>".$row[1]."</td>
									      <td>".$row[2]."</td>
									      <td>".$row[3]."</td>
									      <td>".$row[4]."</td>
									      <td>".$row[5]."</td>
									      <td><a onclick='editar(".$row[0].", 1)'>Editar</a></td>
									      <td><a onclick='eliminar(".$row[0].", 1)'>Eliminar</a></td>
									    </tr>";
				  		}
				  	?>
				  </tbody>
				</table>
				<button type="button" class="btn btn-primary" onclick="agregar('1')">Agregar hotel</button>
				<br/><br/><br/>
				<br/>
			</section>
		</div>

		<?php
			footer();
		?>
	</main>

	<!--MODAL Carrito-->
	<?php
		modalCarrito(0);
	?>

	<!--MODAL grafica-->
	<?php
		modalGrafica();
	?>

	<script type='text/javascript'>
		function agregar(tipo){
			window.location.href = "agregar.php?tipo=" + tipo;
		}
		
		function eliminar(id, tipo){
			var agree=confirm("¿Realmente desea eliminarlo? ");
	  		if(agree)
	     		window.location.href = "eliminarProductos.php?id="+ id + "&tipo=" + tipo; 
			else
	    		alert('No se elimino el registro');
		}

		function editar(id, tipo){
     		window.location.href = "editar.php?id="+ id + "&tipo=" + tipo; 
		}
		
	</script>
	

	<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

	<?php
		echo "<script type='text/javascript'>
      			google.charts.load('current', {'packages':['corechart']});
      			google.charts.setOnLoadCallback(drawChart);

      	function drawChart() {

        var data = google.visualization.arrayToDataTable([
        	['Task', 'Hours per Day']\n";
		$sql = conectar();

		$query = "select nombre, n_vuelos_vendidos FROM destinos";
		$result = mysqli_query($sql, $query);

		while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
			echo ",['".$row[0]."', ".$row[1]."]\n";
		}

	echo "]);

	        var options = {
	          title: 'My Daily Activities'
	        };

	        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

	        chart.draw(data, options);
	      }
	    </script>";

	?>
	
</body>
</html>