<?php
include("php/util.php");
cabecera("Agrega");
session_start();

if(isset($_GET['tipo'])){
	$tipo = $_GET['tipo'];
	if(isset($_GET['nombre']) && isset($_GET['costo']) && isset($_GET['disponibles']) && isset($_GET['descripcion']) && isset($_GET['imagen'])){
		$nombre = $_GET['nombre'];
		$costo = $_GET['costo'];
		$disponibles = $_GET['disponibles'];
		$descripcion = $_GET['descripcion'];
		$img_name = $_GET['imagen'];
		$url = "./imgs/" . $img_name;
		$sql = conectar();

		if($tipo == 0)
			$insert = "INSERT INTO destinos(id, nombre, costo, url_img, n_vuelos_total, descripcion) VALUES (NULL, '$nombre', '$costo', '$url', '$disponibles', '$descripcion')";
		else if($tipo == 1)
			$insert = "INSERT INTO hoteles(id, nombre, costo, url_img, n_habitaciones_total, n_habitaciones_vendidos, descripcion) VALUES (NULL, '$nombre', '$costo', '$url', '$disponibles', '0', '$descripcion')";
		mysqli_query($sql, $insert);
		mysqli_close($sql);
		header('Location: editarServicios.php');
	}
}
?>

<body>
	<main>
		<?php
			impHeader();
			impNavbar();
		?>
	<div class="container">
		<div>
			<br/>
			<h1>Agrega un nuevo producto</h1>
			<br/><br/>
		</div>
		<form action="agregar.php" method="get">
		  <div class="form-group row">
		    <label for="nombre" class="col-sm-2 col-form-label">Nombre</label>
		    <div class="col-sm-8">
		      <input type="text" class="form-control" id="nombre" name="nombre" placeholder="Nombre" />
		    </div>
		  </div>
		  <br/>
		  <div class="form-group row">
		    <label for="costo" class="col-sm-2 col-form-label">Precio</label>
		    <div class="col-sm-8">
		      <input type="text" class="form-control" id="costo" name="costo" placeholder="Precio" />
		    </div>
		  </div>
		  <br/>
			<div class="form-group row">
		    <label for="imagen" class="col-sm-2 col-form-label">URL Imagen</label>
		    <div class="col-sm-8">
		      <input id="imagen" name="imagen" type="file" />
		    </div>
		  </div>
		  <br/>
			<div class="form-group row">
		    <label for="disponibles" class="col-sm-2 col-form-label">Disponibles</label>
		    <div class="col-sm-8">
		      <input type="text" class="form-control" id="disponibles" name="disponibles" placeholder="Disponibles">
		    </div>
		  </div>
		  <br/>
			<div class="form-group row">
		    <label for="descripcion" class="col-sm-2 col-form-label">Descripcion</label>
		    <div class="col-sm-8">
		      <input type="text" class="form-control" id="descripcion" name="descripcion" placeholder="Descripcion">
		    </div>
		  </div>
		  <br/>
		  <?php echo "<input type='hidden' value='$tipo' name='tipo' id='tipo' />"; ?>
		  <div class="form-group row">
		    <div class="col-sm-10 offset-sm-2">
		      <button type="submit" class="btn btn-primary btn-md">Agregar</button>
		    </div>
		  </div>
		</form>
	</div>
	<?php footer(); ?>
</main>
</body>
</html>

