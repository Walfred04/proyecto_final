<?php

function conectar(){
	$con = mysqli_connect("localhost", "root", "rogelioesmuygay", "viajes") or die ("Error durante la conexion.".mysqli_error($con));
	return $con;
}

function impNavbar(){
	echo "<div class='container-fluid'>
			<nav class='navbar navbar-expand-lg navbar-light bg-light'>
			  <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarSupportedContent' aria-controls='navbarSupportedContent' aria-expanded='false' aria-label='Toggle navigation'>
			    <span class='navbar-toggler-icon'></span>
			  </button>

			  <div class='collapse navbar-collapse' id='navbarSupportedContent'>
			    <ul class='navbar-nav mr-auto'>
			      <li class='nav-item active'>
			        <a class='nav-link' href='index.php'>Vuelos<span class='sr-only'>(current)</span></a>
			      </li>
			      <li class='nav-item active'>
			        <a class='nav-link' href='hoteles.php'>Hoteles</a>
			      </li>";
			      if(isset($_SESSION['tipo'])){
			      	$tipo = $_SESSION['tipo'];
			      	if($tipo == 1){
			      		echo "<li class='nav-item active'>
												<a class='nav-link' href='editarUsuarios.php'>Usuarios</a>
											</li>
											<li class='nav-item active'>
												<a class='nav-link' href='editarServicios.php'>Editar productos</a>
											</li>";
			      	}
			      }
			   echo "</ul>
					    <form class='form-inline my-2 my-lg-0' action='busquedas.php' method='post'>
					      <input name='busqueda' type='text' id='busqueda' class='form-control mr-sm-2' placeholder='Busqueda' />
					      <button class='btn btn-primary my-2 my-sm-0' type='submit'>Buscar</button>
					    </form>
					  </div>
					</nav>
				</div>";
}

function impHeader(){
	echo "<div class='container'>
					<header class='row'>
						<div class='col-xs-4 col-sm-4 col-md-4 col-lg-4'>
							<img src='./imgs/logo.png' class='img-fluid' alt='Responsive image'>
						</div>";
						
							$usuario = $_SESSION['usuario'];
							if(isset($_SESSION['usuario'])){
								echo "<div class='col-xs-2 col-sm-2 col-md-2 col-lg-2 info'>
												<a href='logout.php' title='usuario: $usuario'><i class='fa fa-sign-out fa' aria-hidden='true'></i> Salir</a>
											</div>
											<div class='col-xs-2 col-sm-2 col-md-2 col-lg-2 info'>
												<a data-toggle='modal' data-target='#modalCarrito' title='Mostrar carrito'><i class='fa fa-shopping-cart fa' aria-hidden='true'></i> Carrito</a>
											</div>";
								$tipo = $_SESSION['tipo'];
								$tipo = (int)$tipo;
								if($tipo == 1){
									echo "<div class='col-xs-2 col-sm-2 col-md-2 col-lg-2 info'>
													<a data-toggle='modal' data-target='#modalGraficas' title='Estadisticas'><i class='fa fa-bar-chart fa' aria-hidden='true'></i> Estadisticas</a>
												</div>";
								}
							}else{
								echo "<div class='col-xs-2 col-sm-2 col-md-2 col-lg-2 info'>
												<a href='loginCliente.php' title='usuario: $usuario'><img src='./imgs/log_in.png' class='img-fluid' alt='Responsive image'> Iniciar sesion</a>
											</div>
											<div class='col-xs-2 col-sm-2 col-md-2 col-lg-2 info'>
												<a href='registro.php' title='usuario: $usuario'> Registrate</a>
											</div>";
							}
	echo "	</header>
				</div>";
}

function modalGrafica(){
	echo "<div class='modal fade bd-example-modal-lg' id='modalGraficas' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
			  	<div class='modal-dialog modal-lg' role='document'>
			    	<div class='modal-content'>
			      		<div class='modal-header'>
			        		<h5 class='modal-title' id='etiquetaCarrito'>Estadisticas</h5>
			        		<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
			         			<span aria-hidden='true'>&times;</span>
			        		</button>
			     		</div>
			      		<div id='contenidoCarrito' class='modal-body'>
							<div id='piechart'> </div>
						</div>
					</div>
				</div>
			</div>";
}

function modalCarrito($tipo){
	echo "<div class='modal fade bd-example-modal-lg' id='modalCarrito' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
					<div class='modal-dialog modal-lg' role='document'>
						<div class='modal-content'>
							<div class='modal-header'>
								<h5 class='modal-title' id='etiquetaCarrito'>Carrito de compras</h5>
								<button type='button' class='close' data-dismiss='modal' aria-label='Close'>
									<span aria-hidden='true'>&times;</span>
								</button>
							</div>
							<form action='comprar.php' method='get'>
								<div id='contenidoCarrito' class='modal-body'>
									<table id='tablaCarrito' class='table table-hover'>
										<thead class='thead-light'>
										<tr>
											<th></th>
											<th>Descripción</th>
											<th>Precio</th>
											<th>Total</th>
										</tr>
										</thead>
										<tbody>
											
										</tbody>
									</table>
									<div class='alert alert-secondary text-right' role='alert'>
										<h5>Total de la compra <span class='badge badge-secondary mx-3 p-1' id='totalCompra'>0</span></h5>
									</div>";
									
									$usuario = $_SESSION['id'];
									echo "<input type='hidden' value='".$usuario."' name='usuario'>
												<input type='hidden' value='".$tipo."' name='tipo'>
								</div>
								<div class='modal-footer'>
				        			<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cerrar</button>
				        			<button type='submit' class='btn btn-primary'>Comprar</button>
				      			</div>
				      		</form>
						</div>
					</div>
				</div>";
}

function footer(){
	echo "<section class='container-fluid'>
					<footer class='row'>
						<div id='respaldo' class='nav-item col-xs-1 col-sm-4 col-md-3 col-lg-3'>
							<img src='./imgs/respaldo.png' class='img-fluid' alt='Responsive image'>
							<h4>Respaldo</h4><br/>
							<img src='./imgs/logo_profeco.png' class='img-fluid' alt='Responsive image'>
							<img src='./imgs/sectur.png' class='img-fluid' alt='Responsive image'>
						</div>
						<div id='pago' class='nav-item col-xs-1 col-sm-4 col-md-3 col-lg-3'>
							<img src='./imgs/pago.png' class='img-fluid' alt='Responsive image'>
							<h4>Facilidades de pago</h4><br/>
							<img src='./imgs/tarjeta-mastercard.png' class='img-fluid' alt='Responsive image'>
							<img src='./imgs/visa.png' class='img-fluid' alt='Responsive image'>
							<img src='./imgs/maestro.png' class='img-fluid' alt='Responsive image'>
							<img src='./imgs/amex.png' class='img-fluid' alt='Responsive image'>
							<img src='./imgs/paypal.png' class='img-fluid' alt='Responsive image'>
							<a href='#'>Ver todos los medios de pago</a>
						</div>
						<div id='seguridad' class='nav-item col-xs-1 col-sm-4 col-md-3 col-lg-3'>
							<img src='./imgs/candado.png' class='img-fluid' alt='Responsive image'>
							<h4>Sitio seguro</h4><br/>
							<img src='./imgs/seguridad.png' class='img-fluid' alt='Responsive image'>
							<ul>
								<li><a href='#'>Politica de privacidad</a></li>
								<li><a href='#'>Terminos y condiciones</a></li>
							</ul>
						</div>
						<div id='contacto' class='nav-item col-xs-1 col-sm-4 col-md-3 col-lg-3'>
							<img src='./imgs/agenda.png' class='img-fluid' alt='Responsive image'>
							<h4>Contacto</h4><br/>
							<ul>
								<li><span class='cel'>0810-222-2826</span></li>
								<li>Lun a Vie de 8 a 20hs.</li>
								<li>Sab y Dom de 9 a 15hs.<br/></li>
								<li><a href='#'>Centro de ayuda</a></li>
								<li><a href='#'>Acerca de Viajando</a></li>
							</ul>
						</div>
					</footer>
				</section>";
}

function cabecera($titulo){
	echo "<!DOCTYPE html>
				<html lang='en'>
				<head>
					<meta charset='UTF-8'>
					<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>

					<title>".$titulo."</title>
					<link rel='stylesheet' href='css/bootstrap.min.css'>
					<link rel='stylesheet' href='css/font-awesome.min.css'>
					<link rel='stylesheet' type='text/css' href='css/estilo.css'>
					<link rel='stylesheet' type='text/css' href='css/loginCliente.css'>
					
					<script src='js/funciones.js'></script>
					<script src='js/jquery-3.2.1.slim.min.js'></script>
					<script src='js/popper.min.js'></script>
					<script src='js/bootstrap.js'></script>
					<script type='text/javascript' src='js/canvasjs.min.js'></script>
			        <script type='text/javascript' src='js/jquery-2.2.3.min.js'></script>
			        <script src='//ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js'></script>
			        <script type='text/javascript' src='https://www.google.com/jsapi'></script>
				</head>";
}

function impVendidos(){
	$sql = conectar();
	$query = "select nombre, costo, url_img FROM mas_vendidos";
	echo "<section class='container'>
				<aside id='mas_vendidos'>
					<h3>Vuelos mas vendidos de la semana</h3>
					<ul class='formato_letras'>";
	$result = mysqli_query($sql, $query);
	if(!$result){
		echo "Consulta sin respuesta";
	}else{
		while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
			echo "\n<li>";
			echo "\n\t<img src='".$row[2]."' class='img-fluid' alt='Responsive image'>";
			echo "\n\t<span class='destino'>".$row[0]."</span><span class='desde'>Desde</span><span class='ida'>Ida y vuelta</span><span class='precio'>".$row[1]."</span><span class='moneda'>MXN &nbsp</span>";
			echo "\n</li>";
		}
	}
	echo "	</ul>
				</aside>
			</section>";
}

function impDestinos(){
	$sql = conectar();
	$query = "select nombre, costo, url_img, id FROM destinos";

	echo "<section class='container'>
					<ul id='ofertas' class='formato_letras'>";

	$result = mysqli_query($sql, $query);
	if(!$result){
      echo "Consulta sin respuesta";
  }else{
    while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
    	echo "\n<li class='col-xs-1 col-sm-6 col-md-6 col-lg-6'>";
    	echo "\n\t<img src='".$row[2]."' class='img-fluid' alt='Responsive image'>";
   		echo "\n\t\t<span class='destino'>".$row[0]."</span><span class='desde'>Desde</span><span class='ida'>Ida y vuelta</span><span class='precio'>".$row[1]."</span><span class='moneda'>MXN &nbsp</span>";
   		echo "\n\t<span class='bAgregar'><a href='#' class='btn btn-primary' onclick='agregar(".$row[3].", \"".$row[0]."\", ".$row[1].")'>Agregar <i class='fa fa-cart-plus' aria-hidden='true'></i></a></span>";
   		echo "<a style=color:blue onclick='masInfo(".$row[3].",0)'>Mas info</a>";
   		echo "\n</li>";
   	}
  }
  echo "</ul>
		</section>";
	mysqli_close($sql);
}

function impFinanciacion(){
	echo "<section class='container'>
					<aside id='financiacion'>
						<img src='./imgs/pagos.png' class='img-fluid' alt='Responsive image'>
						<a href='#'>Ver planes de financiacion</a>
					</aside>
				</section>";
}

function impImgPrincipal($url){
	echo "<section id='imagen_principal' class='container-fluid'>
					<img src='" . $url . "'class='img-fluid' alt='Responsive image'>
				</section>'";
}

function impBusqueda($busqueda){
	$sql = conectar();
	$query = "select nombre, costo, url_img, id from destinos where nombre='$busqueda'";
	$result1 = mysqli_query($sql, $query);
	$query = "select nombre, costo, url_img, id from hoteles where nombre='$busqueda'"; 
	$result2 = mysqli_query($sql, $query);

	echo "<section class='container'>
					<ul id='ofertas' class='formato_letras'>";
	if(!$result1 && !$result2){
      echo "<li>No hay resultados</li>";
  }else{
    while($row = mysqli_fetch_array($result1, MYSQLI_NUM)){
    	echo "\n<li class='col-xs-1 col-sm-6 col-md-6 col-lg-6'>";
    	echo "\n\t<a onclick='masInfo(".$row[3].",0)'><img src='".$row[2]."' class='img-fluid' alt='Responsive image'></a>";
   		echo "\n\t\t<span class='destino'>".$row[0]."</span><span class='desde'>Desde</span><span class='ida'>Ida y vuelta</span><span class='precio'>".$row[1]."</span><span class='moneda'>MXN &nbsp</span>";
   		echo "\n\t<span class='bAgregar'><a href='#' class='btn btn-primary' onclick='agregar(".$row[3].", \"".$row[0]."\", ".$row[1].")'>Agregar <i class='fa fa-cart-plus' aria-hidden='true'></i></a></span>";
   		echo "<a style=color:blue onclick='masInfo(".$row[3].",0)'>Mas info</a>";
   		echo "\n</li>";
   	}
   	while($row = mysqli_fetch_array($result2, MYSQLI_NUM)){
    	echo "\n<li class='col-xs-1 col-sm-6 col-md-6 col-lg-6'>";
    	echo "\n\t<a onclick='masInfo(".$row[3].",1)'><img src='".$row[2]."' class='img-fluid' alt='Responsive image'></a>";
   		echo "\n\t\t<span class='destino'>".$row[0]."</span><span class='desde'>Desde</span><span class='ida'>Por habitacion</span><span class='precio'>".$row[1]."</span><span class='moneda'>MXN &nbsp</span>";
   		echo "\n\t<span class='bAgregar'><a href='#' class='btn btn-primary' onclick='agregar(".$row[3].", \"".$row[0]."\", ".$row[1].")'>Agregar <i class='fa fa-cart-plus' aria-hidden='true'></i></a></span>";
   		echo "<a style=color:blue onclick='masInfo(".$row[3].",1)'>Mas info</a>";
   		echo "\n</li>";
   	}
  }
  echo "</ul>
		</section>";

}

function impHoteles(){
	$sql = conectar();
	$query = "select nombre, costo, url_img, id FROM hoteles";

	echo "<section class='container'>
					<ul id='ofertas' class='formato_letras'>";

	$result = mysqli_query($sql, $query);

	if(!$result){
      echo "Consulta sin respuesta";
  }else{
    while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
    	echo "\n<li class='col-xs-1 col-sm-6 col-md-6 col-lg-6'>";
    	echo "\n\t<a onclick='masInfo(".$row[3].",1)'><img src='".$row[2]."' class='img-fluid' alt='Responsive image'></a>";
   		echo "\n\t\t<span class='destino'>".$row[0]."</span><span class='desde'>Desde</span><span class='ida'>Por habitacion</span><span class='precio'>".$row[1]."</span><span class='moneda'>MXN &nbsp</span>";
   		echo "\n\t<span class='bAgregar'><a href='#' class='btn btn-primary' onclick='agregar(".$row[3].", \"".$row[0]."\", ".$row[1].")'>Agregar <i class='fa fa-cart-plus' aria-hidden='true'></i></a></span>";
   		echo "<a style=color:blue onclick='masInfo(".$row[3].",1)'>Mas info</a>";
   		echo "\n</li>";
   	}
  }
  echo "</ul>
		</section>";
	mysqli_close($sql);
}

?>

