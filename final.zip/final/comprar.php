<?php
include("php/util.php");
error_reporting(E_ALL);
if(isset($_GET['id']) && isset($_GET['usuario']) && isset($_GET['tipo'])){
	$ids = $_GET['id'];
	$usuario = $_GET['usuario'];
	$tipo = $_GET['tipo'];
	$sql = conectar();
	$tam = sizeof($ids);

	for($i=1; $i<=$tam; $i++){
		$query = "insert into ventas(destino_id,usuario_id) values('$ids[$i]','$usuario')";
		
		mysqli_query($sql, $query);
		if($tipo == 0)
			$query = "update destinos set n_vuelos_vendidos = n_vuelos_vendidos+1 where destinos.id='$ids[$i]'";
		else
			$query = "update hoteles set n_habitaciones_vendidos = n_habitaciones_vendidos+1 where hoteles.id='$ids[$i]'";
		mysqli_query($sql, $query);
	}
}
if($tipo == 0)
	header('Location: index.php');
else
	header('Location: hoteles.php')
?>