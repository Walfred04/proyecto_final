<?php
include("php/util.php");
cabecera("Edita");
session_start();

if(isset($_GET['tipo']) && isset($_GET['id'])){
	$tipo = $_GET['tipo'];
	$id = $_GET['id'];
	if(isset($_GET['nombre']) && isset($_GET['costo']) && isset($_GET['disponibles']) && isset($_GET['descripcion'])){
		$nombre = $_GET['nombre'];
		$costo = $_GET['costo'];
		$disponibles = $_GET['disponibles'];
		$descripcion = $_GET['descripcion'];
		if(isset($_GET['imagen'])){
			$img_name = $_GET['imagen'];
			$url = "./imgs/" . $img_name;
		}
		$sql = conectar();

		if($tipo == 0){
			$update1 = "update destinos set nombre='$nombre', costo='$costo', url_img='$url', n_vuelos_total='$disponibles', descripcion='$descripcion' WHERE destinos.id = '$id'";
			mysqli_query($sql, $update1);
		}else if($tipo == 1){
			$update2 = "update hoteles set nombre='$nombre', costo='$costo', url_img='$url', n_habitaciones_total='$disponibles', descripcion='$descripcion' WHERE hoteles.id = '$id'";
			mysqli_query($sql, $update2);
		}		
		mysqli_close($sql);
		header('Location: editarServicios.php');
	}
}
?>

<body>
<main>
	<?php
		impHeader();
		impNavbar();
	?>
	<div class='container'>
		<div>
			<br/>
			<h1>Editar</h1>
			<br/><br/>
		</div>
		<?php
			$sql = conectar();
			if($tipo == 0)
				$query = "select nombre, costo, url_img, n_vuelos_total, descripcion from destinos where id='$id'";
			else if($tipo == 1)
				$query = "select nombre, costo, url_img, n_habitaciones_total, descripcion from hoteles where id='$id'";
			$result = mysqli_query($sql, $query);
			while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
				$nombre = $row[0];
				$costo = $row[1];
				$url = $row[2];
				$disponibles = $row[3];
				$descripcion = $row[4];
			}
			mysqli_close($sql);
		?>
		<form action='editar.php' method='get'>
		  <div class='form-group row'>
		    <label for='nombre' class='col-sm-2 col-form-label'>Nombre</label>
		    <div class='col-sm-8'>
		      <?php echo "<input type='text' class='form-control' id='nombre' name='nombre' value='$nombre' />"; ?>
		    </div>
		  </div>
		  <br/>
		  <div class='form-group row'>
		    <label for='costo' class='col-sm-2 col-form-label'>Precio</label>
		    <div class='col-sm-8'>
		      <?php echo "<input type='text' class='form-control' id='costo' name='costo' value='$costo' />"; ?>
		    </div>
		  </div>
		  <br/>
			<div class='form-group row'>
		    <label for='imagen' class='col-sm-2 col-form-label'>URL Imagen</label>
		    <div class='col-sm-8'>
		      <input id='imagen' name='imagen' type='file' />
		    </div>
		  </div>
		  <br/>
			<div class='form-group row'>
		    <label for='disponibles' class='col-sm-2 col-form-label'>Disponibles</label>
		    <div class='col-sm-8'>
		      <?php echo "<input type='text' class='form-control' id='disponibles' name='disponibles' value='$disponibles' />"; ?> 
		    </div>
		  </div>
		  <br/>
			<div class='form-group row'>
		    <label for='descripcion' class='col-sm-2 col-form-label'>Descripcion</label>
		    <div class='col-sm-8'>
		      <?php echo "<input type='text' class='form-control' id='descripcion' name='descripcion' value='$descripcion' />"; ?>
		    </div>
		  </div>
		  <br/>
		  <?php echo "
			  <input type='hidden' value='$tipo' name='tipo' id='tipo' />
			  <input type='hidden' value='$id' name='id' id='id' />";
		  ?>
		  
		  <div class='form-group row'>
		    <div class='col-sm-10 offset-sm-2'>
		      <button type='submit' class='btn btn-primary btn-md'>Actualizar</button>
		    </div>
		  </div>
		</form>
		
	</div>
	<?php footer(); ?>
</main>
</body>
</html>
