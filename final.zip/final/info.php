<?php
include("php/util.php");
cabecera("Info");
session_start();

if(isset($_GET['tipo']) && isset($_GET['id'])){
	$tipo = $_GET['tipo'];
	$id = $_GET['id'];
}
?>

<body>
	<main>
	<?php
		$sql = conectar();
		if($tipo == 0)
			$query = "select nombre, costo, url_img, n_vuelos_total, descripcion, n_vuelos_vendidos from destinos where id='$id'";
		else if($tipo == 1)
			$query = "select nombre, costo, url_img, n_habitaciones_total, descripcion, n_habitaciones_vendidos from hoteles where id='$id'";
		$result = mysqli_query($sql, $query);
		if($row = mysqli_fetch_array($result, MYSQLI_NUM)){
			$nombre = $row[0];
			$costo = $row[1];
			$url = $row[2];
			$total = $row[3];
			$descripcion = $row[4];
			$vendidos = $row[5];
			$disponibles = $total - $vendidos;
		}
		mysqli_close($sql);

		impHeader();
		impNavbar();
	?>
	<br/>
	<section class='container'>
		<?php echo "<img src='" .$url . "'class='img-fluid' alt='Responsive image'>";?>
	</section>
	<br/>
	
	<section class="container">
		<div class="row">
			<label for='nombre' class='col-sm-2'>Nombre</label>
			<div class='col-sm-8'>
		     <?php echo "<label  id='nombre'>".$nombre."</label>"; ?>
		   </div>
		</div>
		<br/>
		<div class="row">
			<label for='costo' class='col-sm-2'>Precio</label>
			<div class='col-sm-8'>
		     <?php echo "<label  id='costo'>MXN ".$costo."</label>"; ?>
		  </div>
		</div>
		<br/>
		<div class="row">
			<label for='descripcion' class='col-sm-2'>Descripcion</label>
			<div class='col-sm-8'>
		     <?php echo "<label  id='nombre'>".$descripcion."</label>"; ?>
		   </div>
		</div>
		<br/>
		<div class="row">
			<label for='descripcion' class='col-sm-2'>Disponibles</label>
			<div class='col-sm-8'>
		     <?php echo "<label  id='nombre'>".$disponibles."</label>"; ?>
		   </div>
		</div>
	</section>
	<?php footer(); ?>
</main>
</body>
</html>