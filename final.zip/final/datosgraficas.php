<?php
	include("php/util.php");
	$sql = conectar();

	$data = array();

	$query = "select nombre, n_vuelos_vendidos FROM destinos";
	$result = mysqli_query($sql, $query);

	while($row = mysqli_fetch_array($result, MYSQLI_NUM)){
		$dupla = array("destino" => $row[0], "vendidos" => $row[1]);
		array_push($datos, $dupla);
	}

	echo json_encode($datos);

?>