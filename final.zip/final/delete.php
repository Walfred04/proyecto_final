<?php
include('php/util.php');
if(isset($_GET['id'])){
	$sql = conectar();
	$id = $_GET['id'];
	$query = "delete from usuarios where id = '$id'";
	mysqli_query($sql, $query);
	mysqli_close($sql);
	header('Location: editarUsuarios.php');
}
?>