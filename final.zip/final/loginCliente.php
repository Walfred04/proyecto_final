<?php
include("php/util.php");
cabecera("Entrar a Viajando!");
if(isset($_POST['usuario']) && isset($_POST['password'])){
	$usuario = $_POST['usuario'];
	$password = $_POST['password'];

	$sql = conectar();
	$query = "SELECT id, username, password, email, tipo from usuarios where email='$usuario' and password='$password'";
	$result = mysqli_query($sql, $query);
  mysqli_close($sql);

	if($row = mysqli_fetch_array($result, MYSQLI_NUM)){
		session_start();
		$_SESSION['id'] = $row[0];
		$_SESSION['nombre'] = $row[1];
		$_SESSION['usuario'] = $row[3];
    $_SESSION['tipo'] = $row[4];

		header('Location: index.php');
	}else{
		$error = "error";
	}
}
?>

<body>
   <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-2 col-xl-4"></div>
            <div class="col-lg-4 col-md-4 col-sm-8 col-xl-4">
                <form action="loginCliente.php" method="post">
                    <div class="form-login login">
                        <h5>Bienvenido, <br/> ingresa tus datos</h5>
                        <?php
                            if($error == "error")
                                echo "<p style=color:red> Datos incorrectos</p>";
                        ?>
                        <input name="usuario" type="text" id="usuario" class="form-control  my-2 " placeholder="Correo electrónico" /><br/>
                        <input name="password" type="text" id="password" class="form-control my-2 " placeholder="Password" /><br/>
                        <div class="wrapper">
                            <span class="group-btn">     
                                <button type="submit" class="btn btn-primary btn-md">Entrar <i class="fa fa-sign-in"></i></button>
                            </span>
                        </div>
                    </div>
                </form>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-2 col-xl-4"></div>
        </div>
    </div>
</body>
</html>