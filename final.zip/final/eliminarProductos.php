<?php
include('php/util.php');
if(isset($_GET['id']) && isset($_GET['tipo'])){
	$sql = conectar();
	$id = $_GET['id'];
	$tipo = $_GET['tipo'];

	if($tipo == 0)
		$query = "delete from destinos where id = '$id'";
	else if($tipo == 1)
		$query = "delete from hoteles where id = '$id'";

	mysqli_query($sql, $query);
	mysqli_close($sql);
	header('Location: editarServicios.php');
}
?>